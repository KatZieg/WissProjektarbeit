ADOBE INDESIGN - INFORMATIONEN

SATZDATEINAME: 		210x297_Paper_FormatVorlage2_CS6.indd

PACKDATUM: 		24.07.14 13:11
Erstellungsdatum 	24.07.14
Änderungsdatum: 	24.07.14

Externe Zusatzmodule 0
Nicht deckende Objekte:Ohne

SCHRIFTARTEN
5 Schriftart(en) verwendet; 0 fehlend, 0 eingebettet, 0 unvollst., 0 geschützt

Schriftarten nicht verpackt
- Name: Helvetica; Typ: TrueType, Status: OK
- Name: Helvetica-Bold; Typ: TrueType, Status: OK
- Name: TimesNewRomanPS-BoldMT; Typ: OpenType TrueType, Status: OK
- Name: TimesNewRomanPS-ItalicMT; Typ: OpenType TrueType, Status: OK
- Name: TimesNewRomanPSMT; Typ: OpenType TrueType, Status: OK


FARBEN UND DRUCKFARBEN
4 Prozessfarbe(n); 0 Volltonfarbe(n)
CMS ist deaktiviert

- Name und Typ: Prozessfarbe Cyan; Winkel: 71,565; Linien/Zoll: 63,245
- Name und Typ: Prozessfarbe Magenta; Winkel: 18,434; Linien/Zoll: 63,245
- Name und Typ: Prozessfarbe Gelb; Winkel: 0,000; Linien/Zoll: 66,666
- Name und Typ: Prozessfarbe Schwarz; Winkel: 45,000; Linien/Zoll: 70,710


VERKNÜPFUNGEN UND BILDER
(Nur fehlende & eingebettete Verknüpfungen)
Verknüpfungen und Bilder: 0 Verknüpfung(en) gefunden; 0 geändert, 0 fehlend 0 Zugriff nicht möglich
Bilder: 2 eingebettet, 2 verwenden RGB-Farbraum

- Name: (eingebettet); Typ:  RGB; Status: eingebettet
- Name: (eingebettet); Typ:  RGB; Status: eingebettet

DRUCKEINSTELLUNGEN
PPD: Adobe PDF
Druckausgabe: Drucker
Anzahl der Exemplare: 1
Druckbögen: Nein
Gerade/Ungerade Seiten: Beides
Seiten: Alle
Probedruck: Nein
Unterteilung: Ohne
Skalieren: 100 %, 100 %
Seitenposition: Oben links
Ebenen drucken: Sichtbare und druckbare Ebenen
Druckermarken: Ohne
Anschnitt: 0 mm, 0 mm, 0 mm, 0 mm
Farbe: Composite-CMYK
Überfüllungsmodus: Ohne
Bilddaten senden: Auflösung reduzieren
OPI/DCS-Bildersetzung: Nein
Seitenformat: A4
Papierabmessungen: 209,903 mm x 297,039 mm
Format: Hochformat
Negativ: Nein
Spiegelmodus: Aus


DATEIPAKETLISTE

1. 210x297_Paper_FormatVorlage2_CS6.indd; Typ: Adobe InDesign-Satzdatei; Größe: 624K
